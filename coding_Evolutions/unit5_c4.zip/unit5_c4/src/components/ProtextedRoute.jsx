// /orders and /neworder are protected routes
export const ProtectedRoute = ({ children }) => {};
